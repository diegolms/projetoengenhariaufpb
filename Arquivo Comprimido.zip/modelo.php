<!DOCTYPE html>
<html lang="en">
<?php include("head.php");?>
<body>
<?php include("menuHeader.php");?>

	<div class="col-md-9">
		<div class="text-justify">
			<h2>Modelo</h2></br>
			<h4>Escrever alguma coisa sobre isso</h4>
		</div>
	</div>

</body>

</html>
