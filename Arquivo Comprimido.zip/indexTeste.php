<html>
<body>
<?php include("menuHeader.php"); ?>
<p>This is my home page that uses a common menu to save me time when I add
    new pages to my website!</p>
</body>
</html>